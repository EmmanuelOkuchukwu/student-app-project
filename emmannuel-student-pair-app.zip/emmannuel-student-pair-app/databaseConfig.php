<?php


if($_SERVER['HTTP_HOST'] == "emmanuel-student-pair-app:8888")
{
    define('DB_SERVER', 'localhost');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', 'root');
    define('DB_DATABASE', 'emmanuel-sudent-pair-app');
    $db = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
}
else{
    define('DB_SERVER', 'mysql.cms.gre.ac.uk');
    define('DB_USERNAME', 'eo5426c');
    define('DB_PASSWORD', 'eo5426c');
    define('DB_DATABASE', 'mdb_eo5426c');
    $db = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
}
?>